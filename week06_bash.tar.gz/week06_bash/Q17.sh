#!/bin/bash

file_wordcnt() {
    local files=$(ls *.txt)

    for file in $files
    do
        if [ ! -f "$file" ]; then
            continue 
        fi
        
        local result=$(wc -w < "$file")
        echo "$file 파일의 단어는 ${result// /} 개 입니다."
    done
}

file_wordcnt